import{default as t}from"../entry/_page.svelte.6f81ea9f.js";export{t as component};
