import{default as t}from"../entry/error.svelte.c60ceb6d.js";export{t as component};
