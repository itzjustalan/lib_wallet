import{default as t}from"../entry/error.svelte.9837d8dc.js";export{t as component};
