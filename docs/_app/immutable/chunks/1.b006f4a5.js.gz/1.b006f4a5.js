import{default as t}from"../entry/error.svelte.51117a50.js";export{t as component};
