import{default as t}from"../entry/_page.svelte.a784547b.js";export{t as component};
