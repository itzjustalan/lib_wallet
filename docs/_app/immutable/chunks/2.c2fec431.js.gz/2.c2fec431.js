import{default as t}from"../entry/_page.svelte.830537f2.js";export{t as component};
