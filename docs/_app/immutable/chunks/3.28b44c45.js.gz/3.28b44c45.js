import{default as t}from"../entry/test-page.svelte.d96b2ac5.js";export{t as component};
