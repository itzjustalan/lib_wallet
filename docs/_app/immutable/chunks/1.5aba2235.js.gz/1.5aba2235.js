import{default as t}from"../entry/error.svelte.d8273d11.js";export{t as component};
