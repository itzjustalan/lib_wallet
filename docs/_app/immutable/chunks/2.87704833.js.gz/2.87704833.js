import{default as t}from"../entry/_page.svelte.f62a3136.js";export{t as component};
