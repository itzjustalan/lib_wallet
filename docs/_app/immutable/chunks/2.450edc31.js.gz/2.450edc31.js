import{default as t}from"../entry/_page.svelte.1d670030.js";export{t as component};
