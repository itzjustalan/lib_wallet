import{default as t}from"../entry/error.svelte.4d171af8.js";export{t as component};
