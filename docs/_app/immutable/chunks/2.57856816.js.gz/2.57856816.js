import{default as t}from"../entry/_page.svelte.6785f717.js";export{t as component};
