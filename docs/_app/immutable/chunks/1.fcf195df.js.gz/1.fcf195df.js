import{default as t}from"../entry/error.svelte.17074fb1.js";export{t as component};
