import{default as t}from"../entry/error.svelte.98bba5d0.js";export{t as component};
