import{default as t}from"../entry/_page.svelte.12f9d532.js";export{t as component};
