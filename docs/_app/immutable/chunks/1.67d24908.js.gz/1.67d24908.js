import{default as t}from"../entry/error.svelte.30fb8502.js";export{t as component};
