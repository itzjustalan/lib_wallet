import{default as t}from"../entry/_page.svelte.b33edf46.js";export{t as component};
